
 GoBlox Technologies (2003) - Retro Web Preservation & Offline Remake

Este projeto é uma recriação e preservação digital interativa da antiga página web da GoBlox Technologies datada de 2003, totalmente adaptada para funcionar 100% offline e com funcionalidades interativas adicionais.

🚀 Funcionalidades
- **Interface Clássica de 2003: Preservação rigorosa do design original em tabelas HTML, fontes e elementos visuais da época.
- Painel de Controlo Funcional: Sistema de login interativo (admin / goblox2003) que desbloqueia um painel de administração totalmente funcional.
- Navegação Completa: Links funcionais entre a página inicial, secção de soluções (Web Hosting, Server Leasing) e a página institucional.

 💻 Como Executar Localmente
1. Descarrega o repositório ou descompacta o arquivo .zip.
2. Certifica-te de que todos os arquivos HTML e as respetivas pastas de imagens (`_files`) estão na mesma estrutura.
3. Abre o arquivo GO Blox Welcome! em qualquer navegador web moderno (Chrome, Edge, Firefox).
4. Para testar o painel administrativo, utiliza as credenciais de teste na barra de login lateral:
   - conta: admin
   - senha: goblox2003

---
*Projeto desenvolvido para fins de preservação histórica da web e engenharia de software retro.